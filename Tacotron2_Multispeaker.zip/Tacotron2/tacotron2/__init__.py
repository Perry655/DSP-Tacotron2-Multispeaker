from .entrypoints import nvidia_tacotron2, nvidia_tts_utils
