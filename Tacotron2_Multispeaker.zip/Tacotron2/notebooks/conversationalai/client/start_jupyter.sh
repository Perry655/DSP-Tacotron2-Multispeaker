jupyter lab --allow-root --ip=0.0.0.0 --no-browser speech_ai_demo.ipynb
